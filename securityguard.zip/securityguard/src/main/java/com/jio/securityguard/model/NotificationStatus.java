package com.jio.securityguard.model;

public enum NotificationStatus {
	NEW,
	VIEWED
}
