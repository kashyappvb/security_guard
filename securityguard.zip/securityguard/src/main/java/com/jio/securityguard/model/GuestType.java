package com.jio.securityguard.model;

public enum GuestType {
	VISITOR,
	DELIVERY
}
